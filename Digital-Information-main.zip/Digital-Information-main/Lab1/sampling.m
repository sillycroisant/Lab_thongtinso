function image = sampling(img, t)
image = img(1:t:end,1:t:end,:);
end